/**
 * NARADA - Officer & Investigator Console Application Logic
 * Implements SIH26188 Multi-Source Identity Intelligence Interface
 */

// Application State
const state = {
  edgeMode: 'OFFLINE',      // 'OFFLINE' | 'ONLINE'
  screeningMode: 'DEEP',    // 'DEEP' | 'FAST'
  activeView: 'ORIGINAL',   // 'ORIGINAL' | 'RECTIFIED' | 'ELA'
  primaryDocB64: null,
  secondaryDocB64: null,
  liveSelfieB64: null,
  rectifiedDocB64: null,
  elaHeatmapB64: null,
  currentResult: null,
  scenarios: [],
  webcamStream: null,
  graphNodes: [],
  graphEdges: [],
  draggedNode: null
};

// DOM Element References
const elements = {
  edgeOfflineBtn: document.getElementById('edgeOfflineBtn'),
  edgeOnlineBtn: document.getElementById('edgeOnlineBtn'),
  modeDeepBtn: document.getElementById('modeDeepBtn'),
  modeFastBtn: document.getElementById('modeFastBtn'),
  telemetryBadge: document.getElementById('telemetryBadge'),
  latencyDisplay: document.getElementById('latencyDisplay'),
  exportReportBtn: document.getElementById('exportReportBtn'),
  scenariosContainer: document.getElementById('scenariosContainer'),
  startWebcamBtn: document.getElementById('startWebcamBtn'),
  captureDocBtn: document.getElementById('captureDocBtn'),
  captureSelfieBtn: document.getElementById('captureSelfieBtn'),
  videoContainer: document.getElementById('videoContainer'),
  webcamVideo: document.getElementById('webcamVideo'),
  primaryDocInput: document.getElementById('primaryDocInput'),
  secondaryDocInput: document.getElementById('secondaryDocInput'),
  selfieInput: document.getElementById('selfieInput'),
  runScreeningBtn: document.getElementById('runScreeningBtn'),
  mainDocPreview: document.getElementById('mainDocPreview'),
  noDocPlaceholder: document.getElementById('noDocPlaceholder'),
  qualityOverlayTag: document.getElementById('qualityOverlayTag'),
  qualityText: document.getElementById('qualityText'),
  viewOriginalBtn: document.getElementById('viewOriginalBtn'),
  viewRectifiedBtn: document.getElementById('viewRectifiedBtn'),
  viewELABtn: document.getElementById('viewELABtn'),
  elaScoreDisplay: document.getElementById('elaScoreDisplay'),
  moireScoreDisplay: document.getElementById('moireScoreDisplay'),
  sharpnessDisplay: document.getElementById('sharpnessDisplay'),
  docPortraitImg: document.getElementById('docPortraitImg'),
  noDocFaceIcon: document.getElementById('noDocFaceIcon'),
  liveSelfieImg: document.getElementById('liveSelfieImg'),
  noSelfieIcon: document.getElementById('noSelfieIcon'),
  bioMatchScore: document.getElementById('bioMatchScore'),
  bioLivenessScore: document.getElementById('bioLivenessScore'),
  bioStatusMessage: document.getElementById('bioStatusMessage'),
  checksumBreakdownList: document.getElementById('checksumBreakdownList'),
  assuranceCard: document.getElementById('assuranceCard'),
  assuranceBadge: document.getElementById('assuranceBadge'),
  actionDirective: document.getElementById('actionDirective'),
  hypothesesList: document.getElementById('hypothesesList'),
  footprintModeBadge: document.getElementById('footprintModeBadge'),
  footprintDetails: document.getElementById('footprintDetails'),
  evidenceGraphCanvas: document.getElementById('evidenceGraphCanvas'),
  reportModal: document.getElementById('reportModal'),
  closeReportBtn: document.getElementById('closeReportBtn'),
  reportPrintArea: document.getElementById('reportPrintArea')
};

// =========================================================================
// INITIALIZATION
// =========================================================================
document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) {
    lucide.createIcons();
  }
  setupEventListeners();
  setupCanvasGraph();
  fetchScenarios();
});

// Setup UI Listeners
function setupEventListeners() {
  // Edge Mode Toggles
  elements.edgeOfflineBtn.addEventListener('click', () => setEdgeMode('OFFLINE'));
  elements.edgeOnlineBtn.addEventListener('click', () => setEdgeMode('ONLINE'));

  // Screening Mode Toggles
  elements.modeDeepBtn.addEventListener('click', () => setScreeningMode('DEEP'));
  elements.modeFastBtn.addEventListener('click', () => setScreeningMode('FAST'));

  // Forensic View Toggles
  elements.viewOriginalBtn.addEventListener('click', () => setForensicView('ORIGINAL'));
  elements.viewRectifiedBtn.addEventListener('click', () => setForensicView('RECTIFIED'));
  elements.viewELABtn.addEventListener('click', () => setForensicView('ELA'));

  // Webcam Controls
  elements.startWebcamBtn.addEventListener('click', toggleWebcam);
  elements.captureDocBtn.addEventListener('click', captureDocumentFromWebcam);
  elements.captureSelfieBtn.addEventListener('click', captureSelfieFromWebcam);

  // File Upload Handlers
  elements.primaryDocInput.addEventListener('change', (e) => handleFileUpload(e, 'PRIMARY'));
  elements.secondaryDocInput.addEventListener('change', (e) => handleFileUpload(e, 'SECONDARY'));
  elements.selfieInput.addEventListener('change', (e) => handleFileUpload(e, 'SELFIE'));

  // Run Pipeline Button
  elements.runScreeningBtn.addEventListener('click', executeScreening);

  // Report Modal
  elements.exportReportBtn.addEventListener('click', openReportModal);
  elements.closeReportBtn.addEventListener('click', () => elements.reportModal.classList.add('hidden'));
}

// =========================================================================
// SCENARIOS & DATA LOADING
// =========================================================================
async function fetchScenarios() {
  try {
    const res = await fetch('/api/scenarios');
    state.scenarios = await res.json();
    renderScenariosList();
  } catch (err) {
    console.error('Failed to load scenarios:', err);
    elements.scenariosContainer.innerHTML = '<div class="text-xs text-rose-400">Error connecting to NARADA backend.</div>';
  }
}

function renderScenariosList() {
  elements.scenariosContainer.innerHTML = '';
  state.scenarios.forEach((sc, idx) => {
    const btn = document.createElement('button');
    btn.className = 'w-full text-left p-2.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 transition flex items-start space-x-2.5 group';
    
    // Status indicator
    let badgeColor = 'bg-emerald-500';
    if (sc.expected_state === 'HIGH_CONFIDENCE_FRAUD') badgeColor = 'bg-rose-500';
    else if (sc.expected_state === 'INCONSISTENT') badgeColor = 'bg-amber-500';

    btn.innerHTML = `
      <span class="w-2 h-2 rounded-full ${badgeColor} mt-1.5 flex-shrink-0"></span>
      <div class="flex-1 min-w-0">
        <div class="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 truncate">${sc.title}</div>
        <div class="text-[10px] text-slate-400 line-clamp-1">${sc.description}</div>
      </div>
    `;

    btn.addEventListener('click', () => loadScenario(sc));
    elements.scenariosContainer.appendChild(btn);
  });

  // Automatically load first scenario on page load
  if (state.scenarios.length > 0) {
    loadScenario(state.scenarios[0]);
  }
}

function loadScenario(sc) {
  state.primaryDocB64 = sc.doc_image_b64;
  state.liveSelfieB64 = sc.live_selfie_b64;
  state.secondaryDocB64 = sc.secondary_doc_b64 || null;

  // Update image preview
  setPrimaryDocPreview(state.primaryDocB64);

  // Update live selfie preview
  if (state.liveSelfieB64) {
    elements.liveSelfieImg.src = state.liveSelfieB64;
    elements.liveSelfieImg.classList.remove('hidden');
    elements.noSelfieIcon.classList.add('hidden');
  }

  // Auto-execute screening
  executeScreening();
}

// =========================================================================
// WEBCAM & INPUT HANDLING
// =========================================================================
async function toggleWebcam() {
  if (state.webcamStream) {
    // Stop webcam
    state.webcamStream.getTracks().forEach(t => t.stop());
    state.webcamStream = null;
    elements.webcamVideo.srcObject = null;
    elements.videoContainer.classList.add('hidden');
    elements.startWebcamBtn.innerHTML = '<i data-lucide="video" class="w-3.5 h-3.5"></i><span>Start Webcam</span>';
    elements.captureDocBtn.disabled = true;
    elements.captureSelfieBtn.disabled = true;
    if (window.lucide) lucide.createIcons();
    return;
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' }
    });
    state.webcamStream = stream;
    elements.webcamVideo.srcObject = stream;
    elements.videoContainer.classList.remove('hidden');
    elements.startWebcamBtn.innerHTML = '<i data-lucide="video-off" class="w-3.5 h-3.5"></i><span>Stop Webcam</span>';
    elements.captureDocBtn.disabled = false;
    elements.captureSelfieBtn.disabled = false;
    if (window.lucide) lucide.createIcons();
  } catch (err) {
    alert('Webcam access error: ' + err.message);
  }
}

function captureDocumentFromWebcam() {
  const b64 = grabVideoFrame();
  if (b64) {
    state.primaryDocB64 = b64;
    setPrimaryDocPreview(b64);
    executeScreening();
  }
}

function captureSelfieFromWebcam() {
  const b64 = grabVideoFrame();
  if (b64) {
    state.liveSelfieB64 = b64;
    elements.liveSelfieImg.src = b64;
    elements.liveSelfieImg.classList.remove('hidden');
    elements.noSelfieIcon.classList.add('hidden');
    executeScreening();
  }
}

function grabVideoFrame() {
  if (!elements.webcamVideo.videoWidth) return null;
  const canvas = document.createElement('canvas');
  canvas.width = elements.webcamVideo.videoWidth;
  canvas.height = elements.webcamVideo.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(elements.webcamVideo, 0, 0);
  return canvas.toDataURL('image/jpeg', 0.9);
}

function handleFileUpload(event, type) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    const b64 = e.target.result;
    if (type === 'PRIMARY') {
      state.primaryDocB64 = b64;
      setPrimaryDocPreview(b64);
    } else if (type === 'SECONDARY') {
      state.secondaryDocB64 = b64;
    } else if (type === 'SELFIE') {
      state.liveSelfieB64 = b64;
      elements.liveSelfieImg.src = b64;
      elements.liveSelfieImg.classList.remove('hidden');
      elements.noSelfieIcon.classList.add('hidden');
    }
  };
  reader.readAsDataURL(file);
}

function setPrimaryDocPreview(b64) {
  elements.mainDocPreview.src = b64;
  elements.mainDocPreview.classList.remove('hidden');
  elements.noDocPlaceholder.classList.add('hidden');
  setForensicView('ORIGINAL');
}

// =========================================================================
// SCREENING PIPELINE EXECUTION
// =========================================================================
async function executeScreening() {
  if (!state.primaryDocB64) {
    alert('Please provide or capture a primary document.');
    return;
  }

  elements.runScreeningBtn.disabled = true;
  elements.runScreeningBtn.innerHTML = '<span class="animate-spin mr-2">⚙</span> Screening...';

  const payload = {
    doc_image_b64: state.primaryDocB64,
    live_selfie_b64: state.liveSelfieB64,
    secondary_doc_b64: state.secondaryDocB64,
    screening_mode: state.screeningMode,
    edge_mode: state.edgeMode
  };

  try {
    const res = await fetch('/api/screen/pipeline', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    state.currentResult = data;
    renderScreeningResults(data);
  } catch (err) {
    console.error('Screening failed:', err);
    alert('Failed to execute screening pipeline: ' + err.message);
  } finally {
    elements.runScreeningBtn.disabled = false;
    elements.runScreeningBtn.innerHTML = '<i data-lucide="scan" class="w-4 h-4"></i><span>EXECUTE SCREENING PIPELINE</span>';
    if (window.lucide) lucide.createIcons();
  }
}

// =========================================================================
// RENDER SCREENING RESULTS
// =========================================================================
function renderScreeningResults(data) {
  // 1. Latency & Telemetry
  elements.latencyDisplay.textContent = `${data.latency_ms}ms`;

  // 2. Quality Gate
  const qg = data.quality_gate;
  elements.qualityOverlayTag.classList.remove('hidden');
  if (qg.passed) {
    elements.qualityText.textContent = `QUALITY: PASS (Blur: ${qg.blur_score})`;
    elements.qualityOverlayTag.className = 'absolute top-2 right-2 px-2 py-1 rounded bg-slate-900/90 border border-emerald-500/50 text-[10px] font-mono text-emerald-400 flex items-center space-x-1';
  } else {
    elements.qualityText.textContent = `QUALITY: ISSUE DETECTED (${qg.issues[0] || 'Check capture'})`;
    elements.qualityOverlayTag.className = 'absolute top-2 right-2 px-2 py-1 rounded bg-slate-900/90 border border-amber-500/50 text-[10px] font-mono text-amber-400 flex items-center space-x-1';
  }

  // 3. Document Forensics
  const fn = data.forensics;
  state.elaHeatmapB64 = fn.heatmap_base64;
  state.rectifiedDocB64 = data.rectification.rectified_image_b64;

  elements.elaScoreDisplay.textContent = `${fn.ela_score}%`;
  elements.elaScoreDisplay.className = `text-sm font-bold ${fn.ela_score > 60 ? 'text-rose-400' : 'text-slate-200'}`;

  elements.moireScoreDisplay.textContent = `${fn.moire_score}%`;
  elements.moireScoreDisplay.className = `text-sm font-bold ${fn.moire_score > 60 ? 'text-rose-400' : 'text-slate-200'}`;

  elements.sharpnessDisplay.textContent = `${qg.blur_score}`;

  // 4. Biometrics
  const bio = data.biometrics;
  if (bio) {
    if (bio.doc_portrait_b64) {
      elements.docPortraitImg.src = bio.doc_portrait_b64;
      elements.docPortraitImg.classList.remove('hidden');
      elements.noDocFaceIcon.classList.add('hidden');
    }
    if (bio.live_face_b64) {
      elements.liveSelfieImg.src = bio.live_face_b64;
      elements.liveSelfieImg.classList.remove('hidden');
      elements.noSelfieIcon.classList.add('hidden');
    }

    elements.bioMatchScore.textContent = `${bio.match_score}%`;
    elements.bioMatchScore.className = `font-mono font-bold ${bio.is_match ? 'text-emerald-400' : 'text-rose-400'}`;

    elements.bioLivenessScore.textContent = bio.liveness_passed ? `PASS (${bio.liveness_score}%)` : `ATTACK (${bio.liveness_score}%)`;
    elements.bioLivenessScore.className = `font-mono font-bold ${bio.liveness_passed ? 'text-emerald-400' : 'text-rose-400'}`;

    elements.bioStatusMessage.textContent = bio.message;
  }

  // 5. Deterministic Checks (ICAO / PAN / Aadhaar)
  renderDeterministicChecks(data.documents[0]);

  // 6. Adversarial Agent & Assurance State
  renderAdversarialAndAssurance(data.adversarial_report);

  // 7. Footprint
  const fp = data.footprint;
  elements.footprintModeBadge.textContent = fp.mode;
  elements.footprintModeBadge.className = `text-[10px] font-mono px-2 py-0.5 rounded border ${fp.mode === 'ONLINE_ENRICHMENT' ? 'text-cyan-400 bg-cyan-950 border-cyan-700' : 'text-emerald-400 bg-emerald-950 border-emerald-700'}`;
  elements.footprintDetails.textContent = fp.message;

  // 8. Identity Evidence Graph
  updateGraphData(data.evidence_graph);
}

function renderDeterministicChecks(doc) {
  const container = elements.checksumBreakdownList;
  container.innerHTML = '';

  if (doc.mrz_details && doc.mrz_details.checks) {
    doc.mrz_details.checks.forEach(chk => {
      const row = document.createElement('div');
      row.className = 'flex items-center justify-between p-1.5 rounded bg-slate-900/60 border border-slate-800';
      row.innerHTML = `
        <span class="text-slate-300 truncate">${chk.field}</span>
        <span class="flex items-center space-x-1.5 font-bold ${chk.valid ? 'text-emerald-400' : 'text-rose-400'}">
          <span>${chk.valid ? 'PASS' : 'FAIL'}</span>
          <span>${chk.valid ? '✓' : '✗'}</span>
        </span>
      `;
      container.appendChild(row);
    });
  } else {
    // PAN / Aadhaar deterministic check
    const row = document.createElement('div');
    row.className = 'p-2 rounded bg-slate-900/60 border border-slate-800 space-y-1';
    row.innerHTML = `
      <div class="flex justify-between font-bold">
        <span>${doc.type} (${doc.document_number})</span>
        <span class="${doc.is_valid ? 'text-emerald-400' : 'text-rose-400'}">${doc.is_valid ? 'VALID FORMAT ✓' : 'FORMAT ERROR ✗'}</span>
      </div>
      <div class="text-[11px] text-slate-400">${doc.notes || 'Verified against national syntax standard.'}</div>
    `;
    container.appendChild(row);
  }
}

function renderAdversarialAndAssurance(adv) {
  // Assurance Card Styling
  elements.assuranceCard.className = 'bg-forensic-card border-2 rounded-xl p-5 shadow-2xl transition duration-300';
  elements.assuranceBadge.textContent = adv.badge;

  if (adv.state_color === 'GREEN') {
    elements.assuranceCard.classList.add('card-glow-green');
    elements.assuranceBadge.className = 'text-lg font-black tracking-wide py-2 px-3 rounded-lg bg-emerald-950/80 border border-emerald-500 text-emerald-300 text-center mb-3';
  } else if (adv.state_color === 'RED') {
    elements.assuranceCard.classList.add('card-glow-red');
    elements.assuranceBadge.className = 'text-lg font-black tracking-wide py-2 px-3 rounded-lg bg-rose-950/80 border border-rose-500 text-rose-300 text-center mb-3 animate-pulse';
  } else if (adv.state_color === 'ORANGE') {
    elements.assuranceCard.classList.add('card-glow-orange');
    elements.assuranceBadge.className = 'text-lg font-black tracking-wide py-2 px-3 rounded-lg bg-amber-950/80 border border-amber-500 text-amber-300 text-center mb-3';
  } else {
    elements.assuranceBadge.className = 'text-lg font-black tracking-wide py-2 px-3 rounded-lg bg-yellow-950/80 border border-yellow-500 text-yellow-300 text-center mb-3';
  }

  elements.actionDirective.textContent = adv.recommended_action;

  // Hypotheses List
  elements.hypothesesList.innerHTML = '';
  adv.hypotheses_evaluated.forEach(hyp => {
    const item = document.createElement('div');
    const isRed = hyp.disproved_identity;
    item.className = `p-2 rounded border ${isRed ? 'bg-rose-950/30 border-rose-800/60' : 'bg-slate-900/60 border-slate-800'}`;
    item.innerHTML = `
      <div class="flex justify-between items-center font-semibold ${isRed ? 'text-rose-300' : 'text-slate-300'}">
        <span>${hyp.hypothesis}</span>
        <span>${isRed ? 'DISPROVED ✗' : 'HELD TRUE ✓'}</span>
      </div>
      <div class="text-[11px] text-slate-400 mt-0.5">${hyp.finding}</div>
    `;
    elements.hypothesesList.appendChild(item);
  });
}

// =========================================================================
// FORENSIC VIEW SWITCHER
// =========================================================================
function setForensicView(view) {
  state.activeView = view;
  elements.viewOriginalBtn.className = 'px-2.5 py-1 rounded ' + (view === 'ORIGINAL' ? 'bg-slate-800 text-cyan-400' : 'text-slate-400 hover:text-white');
  elements.viewRectifiedBtn.className = 'px-2.5 py-1 rounded ' + (view === 'RECTIFIED' ? 'bg-slate-800 text-cyan-400' : 'text-slate-400 hover:text-white');
  elements.viewELABtn.className = 'px-2.5 py-1 rounded flex items-center space-x-1 ' + (view === 'ELA' ? 'bg-slate-800 text-rose-400' : 'text-slate-400 hover:text-white');

  if (view === 'ORIGINAL') {
    elements.mainDocPreview.src = state.primaryDocB64 || '';
  } else if (view === 'RECTIFIED') {
    elements.mainDocPreview.src = state.rectifiedDocB64 || state.primaryDocB64 || '';
  } else if (view === 'ELA') {
    elements.mainDocPreview.src = state.elaHeatmapB64 || state.primaryDocB64 || '';
  }
}

function setEdgeMode(mode) {
  state.edgeMode = mode;
  if (mode === 'OFFLINE') {
    elements.edgeOfflineBtn.className = 'px-3 py-1.5 rounded font-medium flex items-center space-x-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 transition';
    elements.edgeOnlineBtn.className = 'px-3 py-1.5 rounded font-medium flex items-center space-x-1.5 text-slate-400 hover:text-white transition';
  } else {
    elements.edgeOnlineBtn.className = 'px-3 py-1.5 rounded font-medium flex items-center space-x-1.5 bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition';
    elements.edgeOfflineBtn.className = 'px-3 py-1.5 rounded font-medium flex items-center space-x-1.5 text-slate-400 hover:text-white transition';
  }
  if (state.primaryDocB64) executeScreening();
}

function setScreeningMode(mode) {
  state.screeningMode = mode;
  if (mode === 'DEEP') {
    elements.modeDeepBtn.className = 'px-3 py-1.5 rounded font-medium bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition';
    elements.modeFastBtn.className = 'px-3 py-1.5 rounded font-medium text-slate-400 hover:text-white transition';
  } else {
    elements.modeFastBtn.className = 'px-3 py-1.5 rounded font-medium bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 transition';
    elements.modeDeepBtn.className = 'px-3 py-1.5 rounded font-medium text-slate-400 hover:text-white transition';
  }
  if (state.primaryDocB64) executeScreening();
}

// =========================================================================
// INTERACTIVE IDENTITY EVIDENCE GRAPH (CANVAS)
// =========================================================================
function setupCanvasGraph() {
  const canvas = elements.evidenceGraphCanvas;
  const ctx = canvas.getContext('2d');

  function resizeCanvas() {
    canvas.width = canvas.parentElement.clientWidth;
    canvas.height = canvas.parentElement.clientHeight;
  }
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  // Mouse interaction for node dragging
  let isDragging = false;

  canvas.addEventListener('mousedown', (e) => {
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    for (let node of state.graphNodes) {
      const dist = Math.hypot(node.x - mouseX, node.y - mouseY);
      if (dist <= node.radius + 5) {
        state.draggedNode = node;
        isDragging = true;
        break;
      }
    }
  });

  window.addEventListener('mousemove', (e) => {
    if (isDragging && state.draggedNode) {
      const rect = canvas.getBoundingClientRect();
      state.draggedNode.x = e.clientX - rect.left;
      state.draggedNode.y = e.clientY - rect.top;
      drawGraph();
    }
  });

  window.addEventListener('mouseup', () => {
    isDragging = false;
    state.draggedNode = null;
  });
}

function updateGraphData(graphData) {
  if (!graphData || !graphData.nodes) return;
  const canvas = elements.evidenceGraphCanvas;
  const cw = canvas.width;
  const ch = canvas.height;

  const total = graphData.nodes.length;
  state.graphNodes = graphData.nodes.map((n, i) => {
    // Layout in a radial pattern around root
    let x, y;
    if (n.id === 'person_root') {
      x = cw / 2;
      y = ch / 2;
    } else {
      const angle = ((i - 1) / (total - 1)) * Math.PI * 2;
      const radius = Math.min(cw, ch) * 0.35;
      x = cw / 2 + Math.cos(angle) * radius;
      y = ch / 2 + Math.sin(angle) * radius;
    }

    let color = '#10b981'; // green verified
    if (n.status === 'CONTRADICTION') color = '#f43f5e'; // red
    else if (n.status === 'WARNING') color = '#f59e0b'; // yellow

    return {
      ...n,
      x, y,
      radius: n.id === 'person_root' ? 22 : 16,
      color
    };
  });

  state.graphEdges = graphData.edges || [];
  drawGraph();
}

function drawGraph() {
  const canvas = elements.evidenceGraphCanvas;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const nodeMap = {};
  state.graphNodes.forEach(n => nodeMap[n.id] = n);

  // 1. Draw Edges
  state.graphEdges.forEach(edge => {
    const s = nodeMap[edge.source];
    const t = nodeMap[edge.target];
    if (s && t) {
      ctx.beginPath();
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(t.x, t.y);

      if (edge.status === 'CONTRADICTION') {
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 2.5;
        ctx.setLineDash([5, 4]); // Dashed line for conflict
      } else {
        ctx.strokeStyle = '#0284c7';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([]);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }
  });

  // 2. Draw Nodes
  state.graphNodes.forEach(n => {
    // Glow
    ctx.shadowColor = n.color;
    ctx.shadowBlur = 10;

    // Circle
    ctx.beginPath();
    ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
    ctx.fillStyle = '#090d16';
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = n.color;
    ctx.stroke();

    ctx.shadowBlur = 0; // reset glow

    // Icon or short label inside
    ctx.fillStyle = '#f1f5f9';
    ctx.font = '9px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(n.type.substring(0, 3), n.x, n.y);

    // Label below node
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.fillText(n.label.substring(0, 18), n.x, n.y + n.radius + 12);
  });
}

// =========================================================================
// OFFICIAL AUDIT REPORT MODAL
// =========================================================================
function openReportModal() {
  if (!state.currentResult) {
    alert('Please execute a screening before generating an audit report.');
    return;
  }

  const res = state.currentResult;
  const doc = res.documents[0];
  const adv = res.adversarial_report;
  const area = elements.reportPrintArea;

  area.innerHTML = `
    <div class="p-3 bg-slate-950 border border-slate-800 rounded mb-3 flex justify-between">
      <div>
        <div>RECORD ID: <span class="text-cyan-400">NRD-${Math.floor(Date.now() / 1000)}</span></div>
        <div>TIMESTAMP: <span>${new Date().toISOString()}</span></div>
      </div>
      <div class="text-right">
        <div>DEPLOYMENT: <span>Hybrid Edge (${res.edge_mode})</span></div>
        <div>VERIFICATION STATE: <span class="font-bold text-${adv.state_color === 'GREEN' ? 'emerald' : 'rose'}-400">${adv.assurance_state}</span></div>
      </div>
    </div>

    <div class="border border-slate-800 rounded p-3 space-y-1">
      <div class="font-bold text-slate-200 border-b border-slate-800 pb-1">1. PRIMARY IDENTITY CREDENTIAL</div>
      <div>Type: ${doc.type} (#${doc.document_number})</div>
      <div>Name: ${doc.full_name} | DOB: ${doc.dob}</div>
      <div>Deterministic ICAO / Verhoeff Check: ${doc.is_valid ? 'VERIFIED PASSED' : 'CHECK FAILED'}</div>
      <div>Forensic Tamper ELA Score: ${res.forensics.ela_score}%</div>
      <div>Screen Re-capture Moiré Score: ${res.forensics.moire_score}%</div>
    </div>

    <div class="border border-slate-800 rounded p-3 space-y-1">
      <div class="font-bold text-slate-200 border-b border-slate-800 pb-1">2. BIOMETRIC PERSON-TO-ID VERIFICATION (Section II.8)</div>
      <div>Subject Match Correlation: ${res.biometrics ? res.biometrics.match_score + '%' : 'N/A'}</div>
      <div>Liveness / Presentation Attack: ${res.biometrics ? res.biometrics.liveness_message : 'N/A'}</div>
    </div>

    <div class="border border-slate-800 rounded p-3 space-y-1">
      <div class="font-bold text-slate-200 border-b border-slate-800 pb-1">3. ADVERSARIAL AGENT COUNTER-FINDINGS</div>
      <div>${adv.adversarial_summary}</div>
      <div class="mt-1 font-bold text-cyan-400">DIRECTIVE: ${adv.recommended_action}</div>
    </div>

    <div class="text-[10px] text-slate-500 text-center pt-2">
      Authorized by NARADA Smart India Hackathon Prototype (SIH26188 | Team LARPERS).
    </div>
  `;

  elements.reportModal.classList.remove('hidden');
  elements.reportModal.classList.add('flex');
}
