"""
NARADA Test Scenarios & Synthetic Asset Generator
Generates realistic sample identity documents, biometric pairs, and attack vectors
demonstrating the 5 critical evaluation scenarios from the NARADA specification.
"""

import base64
import io
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from typing import Dict, Any, List

def create_face_canvas(seed_type: str = "subject_a") -> np.ndarray:
    """Generates a synthetic facial avatar portrait."""
    img = np.full((200, 160, 3), 235, dtype=np.uint8)

    # Hair/head shape
    if seed_type == "subject_a": # Rahul Kumar
        cv2.ellipse(img, (80, 100), (55, 75), 0, 0, 360, (190, 160, 140), -1) # Face skin
        cv2.ellipse(img, (80, 50), (58, 40), 0, 180, 360, (40, 30, 20), -1) # Hair
        # Eyes
        cv2.circle(img, (60, 90), 6, (30, 20, 10), -1)
        cv2.circle(img, (100, 90), 6, (30, 20, 10), -1)
        # Eyebrows
        cv2.line(img, (50, 80), (70, 80), (30, 20, 10), 3)
        cv2.line(img, (90, 80), (110, 80), (30, 20, 10), 3)
        # Nose & Mouth
        cv2.line(img, (80, 95), (80, 115), (150, 120, 100), 2)
        cv2.ellipse(img, (80, 135), (20, 8), 0, 0, 180, (120, 70, 70), -1)
    elif seed_type == "subject_b": # Impostor / Subject B
        cv2.ellipse(img, (80, 105), (60, 70), 0, 0, 360, (210, 180, 160), -1) # Wider skin
        cv2.ellipse(img, (80, 55), (62, 45), 0, 180, 360, (70, 50, 40), -1) # Brown curly hair
        # Blue Eyes
        cv2.circle(img, (58, 92), 7, (120, 60, 30), -1)
        cv2.circle(img, (102, 92), 7, (120, 60, 30), -1)
        # Beard/Stubble
        cv2.ellipse(img, (80, 135), (45, 30), 0, 0, 180, (140, 110, 90), -1)
        # Nose & Mouth
        cv2.line(img, (80, 98), (76, 116), (160, 130, 110), 2)
        cv2.line(img, (70, 138), (90, 138), (90, 60, 60), 3)
    else: # Tampered / Spliced photo
        cv2.ellipse(img, (80, 100), (52, 70), 0, 0, 360, (170, 140, 120), -1)
        cv2.rectangle(img, (20, 20), (140, 180), (0, 0, 255), 1) # Splice border indicator
        cv2.circle(img, (60, 90), 5, (20, 20, 20), -1)
        cv2.circle(img, (100, 90), 5, (20, 20, 20), -1)

    return img

def create_sample_passport_image(
    name: str = "KUMAR<<RAHUL",
    dob: str = "980514",
    doc_no: str = "J84729104",
    tamper_mode: str = "NONE"
) -> np.ndarray:
    """Generates synthetic Indian Passport page with ICAO MRZ."""
    # Passport standard dimensions approx 600x420
    card = np.full((420, 600, 3), 248, dtype=np.uint8)

    # Security guilloche background simulation
    for y in range(0, 420, 15):
        cv2.line(card, (0, y), (600, y + 20), (230, 238, 248), 1)
        cv2.line(card, (0, y + 20), (600, y), (245, 235, 230), 1)

    # Header Emblem & Title
    cv2.putText(card, "REPUBLIC OF INDIA / BHARAT", (180, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (20, 40, 100), 2)
    cv2.putText(card, "PASSPORT", (270, 68), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (80, 80, 80), 1)

    # Add Portrait photo
    face = create_face_canvas("subject_a" if tamper_mode != "PHOTO_SPLICED" else "tampered")
    card[90:290, 35:195] = face

    # If photo spliced, inject artificial high-contrast boundary artifact to simulate tampering
    if tamper_mode == "PHOTO_SPLICED":
        cv2.rectangle(card, (34, 89), (196, 291), (180, 120, 90), 2)
        # Add high-frequency noise inside photo box to trigger high ELA
        noise = np.random.randint(0, 45, (200, 160, 3), dtype=np.uint8)
        card[90:290, 35:195] = cv2.add(card[90:290, 35:195], noise)

    # Visual Inspection Zone (VIZ)
    cv2.putText(card, "Type: P", (220, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 40, 40), 1)
    cv2.putText(card, "Code: IND", (350, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 40, 40), 1)
    cv2.putText(card, f"Passport No: {doc_no}", (450, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (10, 20, 120), 2)

    cv2.putText(card, f"Given Name: RAHUL", (220, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (20, 20, 20), 2)
    cv2.putText(card, f"Surname: KUMAR", (220, 175), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (20, 20, 20), 2)
    cv2.putText(card, f"Nationality: INDIAN", (220, 205), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 40, 40), 1)
    cv2.putText(card, f"DOB: 14/05/1998", (220, 235), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 40, 40), 1)
    cv2.putText(card, f"Sex: M", (380, 235), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 40, 40), 1)
    cv2.putText(card, f"Date of Expiry: 13/05/2032", (220, 265), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 40, 40), 1)

    # Machine Readable Zone (MRZ) - 2 lines of 44 chars
    cv2.rectangle(card, (20, 320), (580, 405), (255, 255, 255), -1)
    cv2.rectangle(card, (20, 320), (580, 405), (200, 200, 200), 1)

    mrz1 = f"P<INDKUMAR<<RAHUL<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
    mrz2 = f"{doc_no}4IND9805148M3205139<<<<<<<<<<<<<<<4"

    cv2.putText(card, mrz1, (30, 350), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (10, 10, 10), 2)
    cv2.putText(card, mrz2, (30, 385), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (10, 10, 10), 2)

    # If screen recapture mode, inject periodic moiré frequency grid
    if tamper_mode == "SCREEN_RECAPTURE":
        # Create subtle periodic sinusoidal grating
        y_coords, x_coords = np.mgrid[0:420, 0:600]
        grating = (np.sin(x_coords * 0.4) * np.sin(y_coords * 0.4) * 35).astype(np.int16)
        card_int = card.astype(np.int16) + grating[:, :, np.newaxis]
        card = np.clip(card_int, 0, 255).astype(np.uint8)

    return card

def create_sample_pan_image(
    name: str = "RAHUL KUMAR",
    pan_no: str = "ABCPK1234F",
    dob: str = "14/05/1998",
    tamper_mode: str = "NONE"
) -> np.ndarray:
    """Generates synthetic Indian Income Tax PAN Card."""
    card = np.full((320, 520, 3), 242, dtype=np.uint8)

    # Header blue band
    cv2.rectangle(card, (0, 0), (520, 60), (190, 100, 40), -1)
    cv2.putText(card, "INCOME TAX DEPARTMENT", (110, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
    cv2.putText(card, "GOVT. OF INDIA", (200, 52), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (240, 240, 240), 1)

    # Portrait photo
    face = create_face_canvas("subject_a" if tamper_mode != "PHOTO_SPLICED" else "tampered")
    face_resized = cv2.resize(face, (110, 135))
    card[80:215, 30:140] = face_resized

    if tamper_mode == "PHOTO_SPLICED":
        cv2.rectangle(card, (29, 79), (141, 216), (200, 50, 50), 2)
        # Heavy noise to spike ELA
        noise = np.random.randint(40, 180, (135, 110, 3), dtype=np.uint8)
        card[80:215, 30:140] = cv2.add(card[80:215, 30:140], noise)

    # Fields
    cv2.putText(card, f"Permanent Account Number", (165, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (80, 80, 80), 1)
    cv2.putText(card, f"{pan_no}", (165, 125), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (20, 20, 20), 2)

    cv2.putText(card, f"Name: {name}", (165, 160), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (30, 30, 30), 2)
    cv2.putText(card, f"Father's Name: RAMESH KUMAR", (165, 185), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (50, 50, 50), 1)
    cv2.putText(card, f"Date of Birth: {dob}", (165, 210), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 40, 40), 2)

    # QR Code placeholder
    cv2.rectangle(card, (400, 210), (490, 300), (30, 30, 30), -1)
    cv2.rectangle(card, (410, 220), (480, 290), (255, 255, 255), -1)
    cv2.putText(card, "QR", (430, 260), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)

    return card

def np_to_data_uri(img_np: np.ndarray) -> str:
    """Encodes numpy image to base64 data URI."""
    _, buf = cv2.imencode(".jpg", img_np, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
    return f"data:image/jpeg;base64,{base64.b64encode(buf).decode('utf-8')}"

def get_preloaded_scenarios() -> List[Dict[str, Any]]:
    """Returns the 5 demonstration scenarios mapped to SIH evaluation criteria."""
    face_a = create_face_canvas("subject_a")
    face_b = create_face_canvas("subject_b")

    passport_clean = create_sample_passport_image("KUMAR<<RAHUL", "980514", "J84729104", tamper_mode="NONE")
    pan_clean = create_sample_pan_image("RAHUL KUMAR", "ABCPK1234F", "14/05/1998", tamper_mode="NONE")

    passport_screen = create_sample_passport_image("KUMAR<<RAHUL", "980514", "J84729104", tamper_mode="SCREEN_RECAPTURE")
    pan_tampered = create_sample_pan_image("RAHUL KUMAR", "ABCPK1234F", "14/05/1998", tamper_mode="PHOTO_SPLICED")

    # Contradictory PAN (different DOB 1985 vs Passport 1998)
    pan_contradictory = create_sample_pan_image("RAHUL KUMAR", "ABCPK1234F", "20/11/1985", tamper_mode="NONE")

    return [
        {
            "id": "scenario_1",
            "title": "Scenario 1: Genuine Passport (Standard Clearance)",
            "description": "Legitimate Indian passport with authentic ICAO MRZ check-digits, verified portrait match with live webcam subject, and consistent evidence graph.",
            "doc_type": "Passport",
            "doc_image_b64": np_to_data_uri(passport_clean),
            "live_selfie_b64": np_to_data_uri(face_a),
            "secondary_doc_b64": None,
            "expected_state": "CONSISTENT",
            "key_insight": "Automated baseline screening on commodity hardware; passes in ~210ms."
        },
        {
            "id": "scenario_2",
            "title": "Scenario 2: Genuine Document + Impostor Person (Stolen ID)",
            "description": "Authentic passport presented by an impostor. All document forensics & MRZ checksums pass 100%, but live webcam face comparison catches the impostor.",
            "doc_type": "Passport",
            "doc_image_b64": np_to_data_uri(passport_clean),
            "live_selfie_b64": np_to_data_uri(face_b), # Person B presenting Person A's passport!
            "secondary_doc_b64": None,
            "expected_state": "HIGH_CONFIDENCE_FRAUD",
            "key_insight": "Proves 'Document Authenticity != Identity Authenticity' (Section II.8). Caught only by person-to-document biometrics."
        },
        {
            "id": "scenario_3",
            "title": "Scenario 3: Photo Substitution on PAN Card (Digital Splicing)",
            "description": "Physically/digitally altered PAN card where photo was replaced. Error Level Analysis (ELA) detects severe compression disparity and splicing gradient.",
            "doc_type": "PAN Card",
            "doc_image_b64": np_to_data_uri(pan_tampered),
            "live_selfie_b64": np_to_data_uri(face_a),
            "secondary_doc_b64": None,
            "expected_state": "HIGH_CONFIDENCE_FRAUD",
            "key_insight": "ELA forensic heatmap exposes photo swap invisible to casual human inspection."
        },
        {
            "id": "scenario_4",
            "title": "Scenario 4: Cross-Document Conflict (Synthetic Identity)",
            "description": "Passport and PAN card are individually well-formed, but comparing them reveals a 13-year Date of Birth contradiction (1998 in Passport vs 1985 in PAN).",
            "doc_type": "Passport & PAN Bundle",
            "doc_image_b64": np_to_data_uri(passport_clean),
            "live_selfie_b64": np_to_data_uri(face_a),
            "secondary_doc_b64": np_to_data_uri(pan_contradictory),
            "expected_state": "INCONSISTENT",
            "key_insight": "Cross-Document Agent exposes synthetic identity assembly across Indian domestic formats."
        },
        {
            "id": "scenario_5",
            "title": "Scenario 5: Screen Re-Capture / Digital Presentation Attack",
            "description": "Passport displayed on a mobile phone screen presented to checkpost camera. 2D FFT Moiré engine detects LCD sub-pixel frequency spikes.",
            "doc_type": "Passport",
            "doc_image_b64": np_to_data_uri(passport_screen),
            "live_selfie_b64": np_to_data_uri(face_a),
            "secondary_doc_b64": None,
            "expected_state": "HIGH_CONFIDENCE_FRAUD",
            "key_insight": "Catches spoofed documents shown on screens without physical paper/plastic substrate."
        }
    ]
