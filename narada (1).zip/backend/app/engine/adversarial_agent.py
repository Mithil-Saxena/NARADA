"""
NARADA Core Engine - Adversarial Verification Agent ("Try to Disprove It")
Implements Section II.16 (Agent 6), II.17 (Adversarial Verification),
and II.20 (Output Assurance States).
"""

from typing import Dict, Any, List, Tuple, Optional

class AdversarialVerificationAgent:
    """
    Actively attempts to disprove an identity after provisional verification.
    Tests competing attack hypotheses and derives the 4 discrete assurance states.
    """
    def __init__(self):
        pass

    def evaluate(
        self,
        doc_forensics: List[Dict[str, Any]],
        biometrics: Optional[Dict[str, Any]] = None,
        cross_doc_consistency: Optional[Dict[str, Any]] = None,
        footprint: Optional[Dict[str, Any]] = None,
        is_deep_mode: bool = True
    ) -> Dict[str, Any]:
        """
        Runs adversarial hypotheses testing across all collected evidence.
        """
        hypotheses_results = []
        critical_flags = []
        warnings = []

        # -------------------------------------------------------------
        # HYPOTHESIS 1: Stolen Genuine Document Used by Impostor
        # -------------------------------------------------------------
        h1_triggered = False
        h1_details = "Live subject matches document portrait."
        if biometrics and biometrics.get("live_face_b64"):
            if not biometrics.get("is_match", False):
                h1_triggered = True
                h1_details = f"CRITICAL: Document appears genuine, but live presenter fails biometric verification (match score: {biometrics.get('match_score', 0)}%). Impostor presenting stolen ID."
                critical_flags.append(h1_details)
        elif is_deep_mode:
            warnings.append("No live webcam biometric available to test Impostor hypothesis.")

        hypotheses_results.append({
            "hypothesis": "H1: Impostor with Stolen Genuine ID",
            "tested": biometrics is not None and biometrics.get("live_face_b64") is not None,
            "disproved_identity": h1_triggered,
            "finding": h1_details
        })

        # -------------------------------------------------------------
        # HYPOTHESIS 2: Photograph Substitution / Digital Splicing
        # -------------------------------------------------------------
        h2_triggered = False
        h2_details = "No compression anomalies or splicing detected in portrait area."
        for doc in doc_forensics:
            if doc.get("ela_score", 0) > 65.0 or doc.get("is_tampered", False):
                h2_triggered = True
                h2_details = f"CRITICAL: High compression variance (ELA score: {doc.get('ela_score')}%) indicates photo or text tampering in {doc.get('type', 'document')}."
                critical_flags.append(h2_details)
                break

        hypotheses_results.append({
            "hypothesis": "H2: Photo Substitution / Tamper Splicing",
            "tested": len(doc_forensics) > 0,
            "disproved_identity": h2_triggered,
            "finding": h2_details
        })

        # -------------------------------------------------------------
        # HYPOTHESIS 3: Screen Re-Capture / Digital Presentation Attack
        # -------------------------------------------------------------
        h3_triggered = False
        h3_details = "Physical paper/card substrate confirmed. No periodic screen Moiré."
        for doc in doc_forensics:
            if doc.get("is_screen_recapture", False) or doc.get("moire_score", 0) > 60.0:
                h3_triggered = True
                h3_details = f"CRITICAL: Periodic 2D frequency grid detected (Moiré score: {doc.get('moire_score')}%). Document was photographed off a smartphone or computer monitor."
                critical_flags.append(h3_details)
                break

        hypotheses_results.append({
            "hypothesis": "H3: Screen Re-Capture / Moiré Attack",
            "tested": len(doc_forensics) > 0,
            "disproved_identity": h3_triggered,
            "finding": h3_details
        })

        # -------------------------------------------------------------
        # HYPOTHESIS 4: Synthetic Identity (Cross-Document Contradiction)
        # -------------------------------------------------------------
        h4_triggered = False
        h4_details = "Cross-document attributes align consistently."
        if cross_doc_consistency and cross_doc_consistency.get("contradictions"):
            h4_triggered = True
            h4_items = [c.get("description", "") for c in cross_doc_consistency["contradictions"]]
            h4_details = f"CONTRADICTION: Documents individually valid, but cross-document conflict detected: {'; '.join(h4_items)}"
            critical_flags.append(h4_details)

        hypotheses_results.append({
            "hypothesis": "H4: Synthetic Identity / Attribute Conflict",
            "tested": cross_doc_consistency is not None and cross_doc_consistency.get("active", False),
            "disproved_identity": h4_triggered,
            "finding": h4_details
        })

        # -------------------------------------------------------------
        # HYPOTHESIS 5: Document Integrity & Algorithmic Checksum Failure
        # -------------------------------------------------------------
        h5_triggered = False
        h5_details = "All deterministic checksums (ICAO 9303 / Verhoeff / PAN format) verified."
        for doc in doc_forensics:
            if not doc.get("is_valid", True):
                h5_triggered = True
                h5_details = f"CRITICAL: Algorithmic validation failed for {doc.get('type', 'ID')}: {doc.get('notes', 'Checksum mismatch')}"
                critical_flags.append(h5_details)
                break

        hypotheses_results.append({
            "hypothesis": "H5: Checksum / Algorithmic Fabrication",
            "tested": len(doc_forensics) > 0,
            "disproved_identity": h5_triggered,
            "finding": h5_details
        })

        # -------------------------------------------------------------
        # FUSION INTO 4 DISCRETE ASSURANCE STATES
        # -------------------------------------------------------------
        if h1_triggered or h2_triggered or h3_triggered or h5_triggered:
            assurance_state = "HIGH_CONFIDENCE_FRAUD"
            state_color = "RED"
            badge = "🔴 HIGH-CONFIDENCE FRAUD INDICATORS"
            recommended_action = "DETAIN & ESCALATE TO SENIOR FORENSIC UNIT"
        elif h4_triggered:
            assurance_state = "INCONSISTENT"
            state_color = "ORANGE"
            badge = "🟠 INCONSISTENT"
            recommended_action = "SECONDARY VERIFICATION REQUIRED (Clarify Attribute Discrepancies)"
        elif len(warnings) > 0 or len(doc_forensics) == 0:
            assurance_state = "INSUFFICIENT_EVIDENCE"
            state_color = "YELLOW"
            badge = "🟡 INSUFFICIENT EVIDENCE"
            recommended_action = "REQUEST SECONDARY GOVERNMENT ID / RECAPTURE CLEAR FRAME"
        else:
            assurance_state = "CONSISTENT"
            state_color = "GREEN"
            badge = "🟢 CONSISTENT"
            recommended_action = "CLEAR - PROCEED WITH ENTRY / VERIFICATION"

        return {
            "assurance_state": assurance_state,
            "state_color": state_color,
            "badge": badge,
            "recommended_action": recommended_action,
            "critical_flags": critical_flags,
            "warnings": warnings,
            "hypotheses_evaluated": hypotheses_results,
            "adversarial_summary": (
                f"Adversarial verification tested {len(hypotheses_results)} attack vectors. "
                f"{len(critical_flags)} fraud indicators discovered. State assigned: {badge}."
            )
        }
