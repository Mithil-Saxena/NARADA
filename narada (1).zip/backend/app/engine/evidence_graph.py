"""
NARADA Core Engine - Identity Evidence Graph
Implements Section II.4 & II.27: Represents identity as a connected network
of evidence rather than analyzing documents in isolation.
"""

from typing import Dict, Any, List, Optional
import time

class IdentityEvidenceGraph:
    """
    Constructs and manages the multi-source Identity Evidence Graph.
    Nodes: Person, Document, Biometric, Attribute, Footprint, Contradiction.
    Edges: Connects evidence nodes with provenance, confidence, and contradiction states.
    """
    def __init__(self, subject_id: str = "Subject_001"):
        self.subject_id = subject_id
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self.edges: List[Dict[str, Any]] = []
        self.contradictions_count = 0

        # Create root Person node
        self.add_node(
            node_id="person_root",
            label="Claimed Identity",
            node_type="PERSON",
            status="VERIFIED",
            confidence=1.0,
            details={"id": subject_id}
        )

    def add_node(self, node_id: str, label: str, node_type: str, status: str = "PENDING", confidence: float = 1.0, details: Optional[Dict[str, Any]] = None):
        """
        Adds or updates a node in the evidence graph.
        node_type: PERSON | DOCUMENT | BIOMETRIC | ATTRIBUTE | FOOTPRINT | CONTRADICTION
        status: VERIFIED | WARNING | CONTRADICTION | PENDING
        """
        self.nodes[node_id] = {
            "id": node_id,
            "label": label,
            "type": node_type,
            "status": status,
            "confidence": confidence,
            "timestamp": time.time(),
            "details": details or {}
        }
        if status == "CONTRADICTION":
            self.contradictions_count += 1

    def add_edge(self, source_id: str, target_id: str, relationship: str, status: str = "VERIFIED", weight: float = 1.0, reason: Optional[str] = None):
        """
        Connects two evidence nodes with semantic relationship.
        relationship: OWNS | EXTRACTS | MATCHES | CONTRADICTS | CORROBORATES
        """
        self.edges.append({
            "source": source_id,
            "target": target_id,
            "relationship": relationship,
            "status": status,
            "weight": weight,
            "reason": reason or ""
        })

    def to_dict(self) -> Dict[str, Any]:
        """Serializes the graph into nodes and links format for canvas visualization."""
        node_list = list(self.nodes.values())
        return {
            "subject_id": self.subject_id,
            "total_nodes": len(node_list),
            "total_edges": len(self.edges),
            "contradictions_count": self.contradictions_count,
            "nodes": node_list,
            "edges": self.edges
        }

def build_scenario_graph(
    person_name: str,
    documents: List[Dict[str, Any]],
    biometric_result: Optional[Dict[str, Any]],
    cross_check_result: Optional[Dict[str, Any]],
    footprint_result: Optional[Dict[str, Any]],
    adversarial_result: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Constructs a complete evidence graph from analysis results.
    """
    graph = IdentityEvidenceGraph(subject_id=person_name or "Subject_Claimant")

    # 1. Add Documents
    for i, doc in enumerate(documents):
        doc_id = f"doc_{i}_{doc.get('type', 'id').lower().replace(' ', '_')}"
        doc_type = doc.get("type", "Document")
        doc_status = "VERIFIED" if doc.get("is_valid", True) and not doc.get("is_tampered", False) else "CONTRADICTION"

        graph.add_node(
            node_id=doc_id,
            label=f"{doc_type} (#{doc.get('document_number', 'N/A')[:8]})",
            node_type="DOCUMENT",
            status=doc_status,
            confidence=0.95 if doc_status == "VERIFIED" else 0.35,
            details=doc
        )
        graph.add_edge(
            source_id="person_root",
            target_id=doc_id,
            relationship="PRESENTS_DOCUMENT",
            status=doc_status
        )

        # Add key extracted attributes
        if doc.get("dob"):
            attr_id = f"{doc_id}_dob"
            graph.add_node(
                node_id=attr_id,
                label=f"DOB: {doc['dob']}",
                node_type="ATTRIBUTE",
                status="VERIFIED",
                details={"dob": doc["dob"], "source": doc_type}
            )
            graph.add_edge(doc_id, attr_id, "EXTRACTED_FIELD")

        if doc.get("full_name") or doc.get("name"):
            name_val = doc.get("full_name") or doc.get("name")
            attr_id = f"{doc_id}_name"
            graph.add_node(
                node_id=attr_id,
                label=f"Name: {name_val}",
                node_type="ATTRIBUTE",
                status="VERIFIED",
                details={"name": name_val, "source": doc_type}
            )
            graph.add_edge(doc_id, attr_id, "EXTRACTED_FIELD")

    # 2. Add Biometric Node
    if biometric_result:
        is_bio_match = biometric_result.get("is_match", False)
        bio_status = "VERIFIED" if is_bio_match else "CONTRADICTION"
        bio_label = f"Live Face Match ({biometric_result.get('match_score', 0)}%)"

        graph.add_node(
            node_id="bio_face",
            label=bio_label,
            node_type="BIOMETRIC",
            status=bio_status,
            confidence=biometric_result.get("match_score", 0) / 100.0,
            details=biometric_result
        )
        graph.add_edge(
            source_id="person_root",
            target_id="bio_face",
            relationship="LIVE_BIOMETRIC",
            status=bio_status,
            reason=biometric_result.get("message", "")
        )

    # 3. Add Cross-Document Contradictions if any
    if cross_check_result and cross_check_result.get("contradictions"):
        for k, contra in enumerate(cross_check_result["contradictions"]):
            contra_id = f"contra_{k}"
            graph.add_node(
                node_id=contra_id,
                label=f"Conflict: {contra.get('field', 'Attribute')}",
                node_type="CONTRADICTION",
                status="CONTRADICTION",
                confidence=1.0,
                details=contra
            )
            # Edge linking the conflicting documents
            doc1_id = f"doc_0_{contra.get('doc1_type', 'doc').lower().replace(' ', '_')}"
            doc2_id = f"doc_1_{contra.get('doc2_type', 'doc').lower().replace(' ', '_')}"

            if doc1_id in graph.nodes:
                graph.add_edge(doc1_id, contra_id, "CONTRADICTS", status="CONTRADICTION", reason=contra.get("description", ""))
            if doc2_id in graph.nodes:
                graph.add_edge(doc2_id, contra_id, "CONTRADICTS", status="CONTRADICTION", reason=contra.get("description", ""))

    # 4. Add Footprint (OSINT) Node
    if footprint_result and footprint_result.get("active"):
        fp_status = "CONTRADICTION" if footprint_result.get("contradictions") else "VERIFIED"
        fp_label = f"Web Footprint ({footprint_result.get('records_found', 0)} records)"
        graph.add_node(
            node_id="footprint_node",
            label=fp_label,
            node_type="FOOTPRINT",
            status=fp_status if footprint_result.get("records_found", 0) > 0 else "WARNING",
            details=footprint_result
        )
        graph.add_edge(
            source_id="person_root",
            target_id="footprint_node",
            relationship="PUBLIC_CORROBORATION",
            status=fp_status
        )

    return graph.to_dict()
