"""
NARADA Core Engine - Hybrid Edge Footprint & OSINT Engine
Implements Section II.13 (Identity Footprint), II.24 (OSINT Safety Principle),
and Hybrid Edge Architecture (Offline-First by default, Online Enrichment on demand).
"""

from typing import Dict, Any, List, Optional
import datetime

# Mock authorized public registries for simulation of Indian identity footprint
KNOWN_REGISTRY_DATABASE = {
    "RAHUL KUMAR": [
        {
            "source": "Institute of Engineers / MCA Registry",
            "entity": "Rahul Kumar",
            "dob_approx": "1998",
            "role": "Software Engineer / Tech Member",
            "status": "CORROBORATING",
            "year_observed": 2021,
            "details": "Registered technical membership matching claimed identity attributes"
        }
    ],
    "PRIYA SHARMA": [
        {
            "source": "State Medical Council Registry",
            "entity": "Dr. Priya Sharma",
            "dob_approx": "1992",
            "role": "Registered Medical Practitioner",
            "status": "CORROBORATING",
            "year_observed": 2017,
            "details": "Active medical license and professional registration records"
        }
    ],
    "VIKRAM ADITYA SINGH": [
        {
            "source": "MCA Corporate Directors Database",
            "entity": "Vikram Aditya Singh",
            "dob_approx": "1972",
            "role": "Director since 1995",
            "status": "CONTRADICTORY",
            "year_observed": 1995,
            "details": "Director appointment in 1995 conflicts with claimed 1998 birth date (Subject would be -3 years old at appointment)"
        }
    ]
}

def analyze_footprint(
    name: str,
    dob: Optional[str] = None,
    is_online_mode: bool = False
) -> Dict[str, Any]:
    """
    Hybrid Edge Footprint Cross-Check.
    Offline Mode: Skips network lookups; runs in local air-gapped checkpost mode.
    Online Mode: Queries approved registries & public footprints with safety guardrails:
    - CONTRADICTORY evidence is flagged.
    - ABSENCE of evidence is NEVER treated as fraud.
    """
    if not is_online_mode:
        return {
            "active": False,
            "mode": "OFFLINE_EDGE",
            "records_found": 0,
            "corroborated": False,
            "contradictions": [],
            "message": "Hybrid Edge running in OFFLINE mode (air-gapped checkpost operation). Local CV & deterministic checks prioritized.",
            "safety_note": "No public network traffic generated."
        }

    clean_name = name.strip().upper() if name else ""
    records = KNOWN_REGISTRY_DATABASE.get(clean_name, [])

    contradictions: List[Dict[str, Any]] = []
    corroborating_claims: List[Dict[str, Any]] = []

    for r in records:
        if r["status"] == "CONTRADICTORY":
            contradictions.append(r)
        else:
            corroborating_claims.append(r)

    # Check temporal / timeline consistency if DOB available
    if dob and len(records) > 0:
        birth_year = None
        try:
            birth_year = int(dob.split("-")[0])
        except Exception:
            pass

        if birth_year:
            for r in records:
                obs_year = r.get("year_observed")
                if obs_year and (obs_year - birth_year < 16):
                    # Impossible professional achievement before age 16
                    temporal_conflict = {
                        "source": r["source"],
                        "field": "Temporal / Timeline Anomaly",
                        "description": f"Record established in {obs_year} when subject was only {obs_year - birth_year} years old."
                    }
                    if temporal_conflict not in contradictions:
                        contradictions.append(temporal_conflict)

    safety_advisory = (
        "NARADA OSINT Safety Principle Enforced: Contradictory records are weighed as investigative signals. "
        "Absence of online digital footprint is NOT penalized, protecting low-digital-footprint citizens."
    )

    return {
        "active": True,
        "mode": "ONLINE_ENRICHMENT",
        "records_found": len(records),
        "corroborated": len(corroborating_claims) > 0 and len(contradictions) == 0,
        "corroborating_claims": corroborating_claims,
        "contradictions": contradictions,
        "message": (
            f"Footprint scan returned {len(records)} public records. "
            f"{len(contradictions)} contradiction(s) flagged." if len(records) > 0
            else "No public registry footprint found (Absence of footprint is neutral, not fraud)."
        ),
        "safety_note": safety_advisory
    }
