"""
NARADA Forensics - Indian Domestic ID Structure & Algorithmic Validation
Implements Section I.3 (Pivot 2) & II.10: Domestic ID formats (Aadhaar, PAN,
Voter ID / EPIC, State Driving Licences).
"""

import re
from typing import Dict, Any, List, Optional, Tuple

# -------------------------------------------------------------
# 1. VERHOEFF CHECKSUM ALGORITHM (Used by UIDAI for Aadhaar)
# -------------------------------------------------------------

# Multiplication table (d)
_VERHOEFF_D = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
    [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
    [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
    [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
    [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
    [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
]

# Permutation table (p)
_VERHOEFF_P = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
    [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
    [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
    [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
    [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]
]

# Inverse table (inv)
_VERHOEFF_INV = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9]

def validate_verhoeff(num_str: str) -> bool:
    """Validates full string with check digit using Verhoeff algorithm."""
    if not num_str.isdigit():
        return False
    c = 0
    reversed_digits = [int(x) for x in reversed(num_str)]
    for i, digit in enumerate(reversed_digits):
        c = _VERHOEFF_D[c][_VERHOEFF_P[i % 8][digit]]
    return c == 0

def generate_verhoeff(num_str: str) -> int:
    """Calculates Verhoeff check digit for given numeric string."""
    c = 0
    reversed_digits = [int(x) for x in reversed(num_str)]
    for i, digit in enumerate(reversed_digits):
        c = _VERHOEFF_D[c][_VERHOEFF_P[(i + 1) % 8][digit]]
    return _VERHOEFF_INV[c]


# -------------------------------------------------------------
# 2. AADHAAR VALIDATION
# -------------------------------------------------------------

def validate_aadhaar(aadhaar_str: str) -> Dict[str, Any]:
    """
    Validates Indian Aadhaar number (12 digits, Verhoeff checksum).
    Supports masked format (XXXX XXXX 1234).
    """
    clean_str = re.sub(r'[\s\-]', '', aadhaar_str.upper())

    # Check for masked format
    if re.match(r'^[X*]{8}[0-9]{4}$', clean_str):
        return {
            "valid": True,
            "type": "Aadhaar (Masked)",
            "is_masked": True,
            "display_number": f"XXXX XXXX {clean_str[-4:]}",
            "verhoeff_passed": None,
            "notes": "Masked format matches UIDAI security guidelines; 8 digits redacted"
        }

    # Full 12-digit format
    if re.match(r'^[2-9][0-9]{11}$', clean_str):
        is_verhoeff_valid = validate_verhoeff(clean_str)
        formatted = f"{clean_str[0:4]} {clean_str[4:8]} {clean_str[8:12]}"
        return {
            "valid": is_verhoeff_valid,
            "type": "Aadhaar",
            "is_masked": False,
            "display_number": formatted,
            "verhoeff_passed": is_verhoeff_valid,
            "notes": "Valid UIDAI 12-digit format with Verhoeff dihedral D5 checksum" if is_verhoeff_valid else "Invalid Verhoeff check digit"
        }

    return {
        "valid": False,
        "type": "Aadhaar",
        "is_masked": False,
        "display_number": aadhaar_str,
        "verhoeff_passed": False,
        "notes": "Format does not match standard 12-digit Aadhaar pattern (cannot start with 0 or 1)"
    }


# -------------------------------------------------------------
# 3. PAN CARD VALIDATION
# -------------------------------------------------------------

PAN_ENTITY_TYPES = {
    'P': 'Individual',
    'C': 'Company',
    'H': 'Hindu Undivided Family (HUF)',
    'F': 'Firm / Limited Liability Partnership (LLP)',
    'A': 'Association of Persons (AOP)',
    'T': 'Trust',
    'B': 'Body of Individuals (BOI)',
    'L': 'Local Authority',
    'J': 'Artificial Juridical Person',
    'G': 'Government Agency'
}

def validate_pan(pan_str: str, surname: Optional[str] = None) -> Dict[str, Any]:
    """
    Validates Indian Permanent Account Number (PAN):
    Format: 5 letters + 4 digits + 1 letter (e.g. ABCDE1234F).
    4th char: Entity category.
    5th char: First letter of surname/last name.
    """
    clean_pan = pan_str.strip().upper().replace(" ", "")

    pan_pattern = r'^[A-Z]{3}([PCHFATBLJG])([A-Z])[0-9]{4}[A-Z]$'
    match = re.match(pan_pattern, clean_pan)

    if not match:
        return {
            "valid": False,
            "type": "PAN Card",
            "number": clean_pan,
            "entity_type": "Unknown",
            "surname_matched": None,
            "notes": "Invalid PAN format. Must be 5 uppercase letters, 4 digits, 1 letter."
        }

    entity_code = match.group(1)
    surname_char = match.group(2)
    entity_name = PAN_ENTITY_TYPES.get(entity_code, "Other Entity")

    surname_matched = None
    notes = [f"Entity type: {entity_name} ({entity_code})"]

    if surname:
        clean_surname = surname.strip().upper()
        if clean_surname and clean_surname[0] == surname_char:
            surname_matched = True
            notes.append(f"5th character '{surname_char}' matches surname initial '{clean_surname[0]}'")
        else:
            surname_matched = False
            notes.append(f"5th character '{surname_char}' CONTRADICTS surname initial '{clean_surname[0] if clean_surname else ''}'")

    return {
        "valid": True,
        "type": "PAN Card",
        "number": clean_pan,
        "entity_type": entity_name,
        "entity_code": entity_code,
        "surname_initial": surname_char,
        "surname_matched": surname_matched,
        "notes": "; ".join(notes)
    }


# -------------------------------------------------------------
# 4. VOTER ID (EPIC) VALIDATION
# -------------------------------------------------------------

def validate_voter_id(epic_str: str) -> Dict[str, Any]:
    """
    Validates Election Commission of India Voter ID (EPIC).
    Format: 3 letters + 7 digits (e.g. ABC1234567) or older state formats.
    """
    clean_epic = epic_str.strip().upper().replace(" ", "")

    # Standard modern 10-char EPIC format
    if re.match(r'^[A-Z]{3}[0-9]{7}$', clean_epic):
        return {
            "valid": True,
            "type": "Voter ID (EPIC)",
            "number": clean_epic,
            "state_code": clean_epic[:3],
            "notes": "Matches standard Election Commission 10-character EPIC format"
        }

    # Alternate 12-char or slash-formatted format
    if re.match(r'^[A-Z]{2}/[0-9]{2,3}/[0-9]{3,6}$', clean_epic):
        return {
            "valid": True,
            "type": "Voter ID (Legacy EPIC)",
            "number": clean_epic,
            "notes": "Matches legacy district/constituency slash-formatted Voter ID"
        }

    return {
        "valid": False,
        "type": "Voter ID (EPIC)",
        "number": clean_epic,
        "notes": "Invalid Voter ID format. Expected 3 letters followed by 7 digits."
    }


# -------------------------------------------------------------
# 5. DRIVING LICENCE (MoRTH / SARATHI) VALIDATION
# -------------------------------------------------------------

INDIAN_STATE_CODES = {
    'AN', 'AP', 'AR', 'AS', 'BR', 'CH', 'CG', 'DD', 'DL', 'DN',
    'GA', 'GJ', 'HR', 'HP', 'JH', 'JK', 'KA', 'KL', 'LA', 'LD',
    'MP', 'MH', 'MN', 'ML', 'MZ', 'NL', 'OD', 'OR', 'PB', 'PY',
    'RJ', 'SK', 'TN', 'TS', 'TR', 'UP', 'UK', 'UA', 'WB'
}

def validate_driving_licence(dl_str: str) -> Dict[str, Any]:
    """
    Validates Indian Driving Licence (Sarathi standard format):
    SS-RR-YYYYNNNNNNN (15 or 16 chars).
    SS: 2-letter state code.
    RR: 2-digit RTO code.
    YYYY: 4-digit issue year.
    NNNNNNN: 7-digit sequential number.
    """
    clean_dl = re.sub(r'[\s\-/]', '', dl_str.upper())

    if len(clean_dl) >= 15:
        state_code = clean_dl[:2]
        rto_code = clean_dl[2:4]
        year = clean_dl[4:8]
        seq = clean_dl[8:]

        is_state_valid = state_code in INDIAN_STATE_CODES
        is_year_valid = year.isdigit() and (1970 <= int(year) <= 2030)
        is_seq_valid = seq.isdigit()

        if is_state_valid and is_year_valid and is_seq_valid:
            formatted = f"{state_code}-{rto_code}-{year}-{seq}"
            return {
                "valid": True,
                "type": "Driving Licence",
                "number": formatted,
                "state_code": state_code,
                "rto_code": rto_code,
                "issue_year": year,
                "notes": f"Standard MoRTH Sarathi format for state {state_code}"
            }

    return {
        "valid": False,
        "type": "Driving Licence",
        "number": dl_str,
        "notes": "Invalid Driving Licence structure. Expected SS-RR-YYYY-NNNNNNN."
    }
