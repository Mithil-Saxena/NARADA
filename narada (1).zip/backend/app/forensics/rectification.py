"""
NARADA Forensics - Perspective Rectification Pipeline
Implements Section II.5.2: Detects document boundaries and rectifies tilted
or perspective-distorted captures into standardized aspect-ratio crops.
"""

import cv2
import numpy as np
from typing import Tuple, Optional, List

def order_points(pts: np.ndarray) -> np.ndarray:
    """
    Orders coordinates: [top-left, top-right, bottom-right, bottom-left]
    """
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)] # TL has smallest sum
    rect[2] = pts[np.argmax(s)] # BR has largest sum

    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)] # TR has smallest diff
    rect[3] = pts[np.argmax(diff)] # BL has largest diff
    return rect

def four_point_transform(image: np.ndarray, pts: np.ndarray) -> np.ndarray:
    """
    Applies perspective warp to extract rectangular top-down document view.
    """
    rect = order_points(pts)
    (tl, tr, br, bl) = rect

    # Width of the new image: max distance between TR & TL or BR & BL
    width_a = np.linalg.norm(br - bl)
    width_b = np.linalg.norm(tr - tl)
    max_width = max(int(width_a), int(width_b))

    # Height of the new image: max distance between TR & BR or TL & BL
    height_a = np.linalg.norm(tr - br)
    height_b = np.linalg.norm(tl - bl)
    max_height = max(int(height_a), int(height_b))

    # Guard against invalid dimensions
    if max_width < 50 or max_height < 50:
        return image

    dst = np.array([
        [0, 0],
        [max_width - 1, 0],
        [max_width - 1, max_height - 1],
        [0, max_height - 1]
    ], dtype="float32")

    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(image, M, (max_width, max_height))
    return warped

def rectify_document(image: np.ndarray) -> Tuple[np.ndarray, bool, List[List[int]]]:
    """
    Finds document contour and extracts perspective-rectified crop.
    Returns: (rectified_image, contour_found, corner_points)
    """
    if image is None or image.size == 0:
        return image, False, []

    orig = image.copy()
    h, w = image.shape[:2]

    # Preprocessing for contour finding
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 50, 180)

    # Dilate edges to close gaps
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    dilated = cv2.dilate(edged, kernel, iterations=2)

    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:5]

    doc_cnt = None
    min_area = (h * w) * 0.15 # Must occupy at least 15% of frame

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < min_area:
            continue
        peri = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        if len(approx) == 4:
            doc_cnt = approx
            break

    if doc_cnt is not None:
        pts = doc_cnt.reshape(4, 2)
        warped = four_point_transform(orig, pts)
        corners = pts.tolist()
        return warped, True, corners

    # Fallback: Central 80% crop if no strict 4-point quadrilateral found
    return orig, False, []
