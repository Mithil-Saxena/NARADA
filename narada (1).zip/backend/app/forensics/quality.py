"""
NARADA Forensics - Image Quality Gating
Implements Section II.5.1: Blur detection, glare detection, exposure analysis,
and capture-quality assessment before downstream models execute.
"""

import cv2
import numpy as np
from typing import Dict, Any, List

def analyze_quality(image_np: np.ndarray) -> Dict[str, Any]:
    """
    Evaluates raw capture quality to prevent downstream misclassifications.
    Returns scores and gating status.
    """
    if image_np is None or image_np.size == 0:
        return {
            "passed": False,
            "blur_score": 0.0,
            "glare_score": 100.0,
            "resolution": (0, 0),
            "issues": ["Empty or unreadable image frame"],
            "recommendation": "Recapture image with clear lighting and steady camera."
        }

    h, w = image_np.shape[:2]
    issues: List[str] = []

    # 1. Convert to grayscale for optical checks
    if len(image_np.shape) == 3:
        gray = cv2.cvtColor(image_np, cv2.COLOR_BGR2GRAY)
    else:
        gray = image_np.copy()

    # 2. Blur Detection (Laplacian Variance)
    # Variance < 95 typically signifies blurry capture on standard webcams
    laplacian_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    is_blurry = laplacian_var < 95.0
    if is_blurry:
        issues.append(f"Image blur detected (sharpness: {laplacian_var:.1f}/100 minimum)")

    # 3. Glare / Overexposure Detection
    # True specular reflection has saturated white pixels >= 254 covering > 30% of total area
    total_pixels = h * w
    saturated_pixels = int(np.sum(gray >= 254))
    glare_percentage = float((saturated_pixels / total_pixels) * 100.0)
    has_glare = glare_percentage > 30.0
    if has_glare:
        issues.append(f"Significant specular glare detected ({glare_percentage:.1f}% saturated area)")

    # 4. Underexposure / Darkness Check
    avg_brightness = float(np.mean(gray))
    is_dark = avg_brightness < 40.0
    if is_dark:
        issues.append(f"Low ambient lighting ({avg_brightness:.1f}/255)")

    # 5. Resolution Gating
    min_dim = min(h, w)
    is_low_res = min_dim < 300
    if is_low_res:
        issues.append(f"Resolution ({w}x{h}) is below minimum OCR reliability threshold (300px min dimension)")

    passed = not (is_blurry or has_glare or (is_dark and avg_brightness < 30.0) or is_low_res)

    recommendation = "Capture quality acceptable for automated forensic pipeline."
    if not passed:
        if is_blurry:
            recommendation = "Hold document steady and allow webcam to autofocus."
        elif has_glare:
            recommendation = "Tilt document slightly away from direct light/overhead bulb to eliminate reflection."
        elif is_dark:
            recommendation = "Increase ambient illumination or checkpost desk lamp."
        elif is_low_res:
            recommendation = "Move document closer to webcam capture zone."

    return {
        "passed": passed,
        "blur_score": round(laplacian_var, 2),
        "is_blurry": is_blurry,
        "glare_percentage": round(glare_percentage, 2),
        "has_glare": has_glare,
        "brightness": round(avg_brightness, 2),
        "resolution": [w, h],
        "issues": issues,
        "recommendation": recommendation
    }
