"""
NARADA Forensics - Tamper Detection Engine
Implements Section II.7 (Document Forensics), II.18 (Unknown-Forgery & Known Attacks),
and Screen Recapture / Moiré detection.
"""

import io
import base64
import cv2
import numpy as np
from PIL import Image, ImageChops
from typing import Dict, Any, List, Tuple

def compute_ela(image_np: np.ndarray, quality: int = 90, scale: float = 18.0) -> Tuple[np.ndarray, np.ndarray, float]:
    """
    Error Level Analysis (ELA):
    Re-compresses the image at known quality (90%) and amplifies pixel delta.
    Altered/spliced areas (e.g., photo substitution or modified digits)
    exhibit distinct error rates compared to original background.
    """
    if len(image_np.shape) == 3 and image_np.shape[2] == 3:
        rgb = cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB)
    else:
        rgb = cv2.cvtColor(image_np, cv2.COLOR_GRAY2RGB)

    orig_pil = Image.fromarray(rgb)

    # Save to memory buffer as JPEG
    buf = io.BytesIO()
    orig_pil.save(buf, format="JPEG", quality=quality)
    buf.seek(0)
    resaved_pil = Image.open(buf)

    # Calculate absolute difference
    diff_pil = ImageChops.difference(orig_pil, resaved_pil)
    diff_np = np.array(diff_pil, dtype=np.float32)

    # Scale difference for visual inspection
    amplified = np.clip(diff_np * scale, 0, 255).astype(np.uint8)
    diff_gray = cv2.cvtColor(amplified, cv2.COLOR_RGB2GRAY)

    h, w = diff_gray.shape

    # Focus on photo quadrant on left side vs document body
    photo_roi = diff_gray[int(h * 0.2):int(h * 0.7), int(w * 0.05):int(w * 0.35)]
    doc_roi = diff_gray[int(h * 0.2):int(h * 0.7), int(w * 0.4):int(w * 0.9)]

    photo_mean = float(np.mean(photo_roi)) if photo_roi.size > 0 else 1.0
    doc_mean = float(np.mean(doc_roi)) + 1e-3 if doc_roi.size > 0 else 1.0
    disc = photo_mean / doc_mean

    # Clean documents have photo error ratio ~0.4 to 1.3
    # Spliced / replaced photos have error ratio > 1.8
    if disc > 1.4:
        ela_score = float(np.clip((disc - 1.3) * 55.0, 0.0, 99.0))
    else:
        ela_score = float(np.clip(disc * 14.0, 3.0, 25.0))

    # Color heatmap for visualization
    heatmap = cv2.applyColorMap(diff_gray, cv2.COLORMAP_JET)

    # Overlay heatmap onto original with 40% blend
    bgr_orig = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    overlay = cv2.addWeighted(bgr_orig, 0.6, heatmap, 0.4, 0)

    return diff_gray, overlay, round(ela_score, 1)

def detect_moire_recapture(image_np: np.ndarray) -> Tuple[float, bool]:
    """
    Detects screen re-capture / moiré patterns via 2D Fast Fourier Transform (FFT).
    Screen pixels (LCD/OLED grid) create periodic high-frequency peaks in the frequency domain.
    """
    if len(image_np.shape) == 3:
        gray = cv2.cvtColor(image_np, cv2.COLOR_BGR2GRAY)
    else:
        gray = image_np.copy()

    # Resize to standard 512x512 for FFT consistency
    resized = cv2.resize(gray, (512, 512), interpolation=cv2.INTER_AREA)

    # Compute 2D Fourier Transform
    dft = cv2.dft(np.float32(resized), flags=cv2.DFT_COMPLEX_OUTPUT)
    dft_shift = np.fft.fftshift(dft)
    magnitude_spectrum = 20 * np.log(cv2.magnitude(dft_shift[:, :, 0], dft_shift[:, :, 1]) + 1e-5)

    # Mask out low-frequency DC center
    rows, cols = 512, 512
    crow, ccol = rows // 2, cols // 2
    r_center = 40
    y, x = np.ogrid[:rows, :cols]
    center_mask = ((x - ccol)**2 + (y - crow)**2) <= r_center**2
    magnitude_spectrum[center_mask] = 0

    # High frequency band analysis
    hf_band = magnitude_spectrum[~center_mask]
    hf_mean = float(np.mean(hf_band))
    hf_std = float(np.std(hf_band))

    # Detect isolated peak points in high-frequency zone (> 3.8 std dev above mean)
    peak_threshold = hf_mean + 3.8 * hf_std
    peaks_count = int(np.sum(magnitude_spectrum > peak_threshold))

    # Calculate Moiré score (0-100)
    moire_score = float(np.clip((peaks_count - 18) * 3.2, 0.0, 100.0))
    is_recaptured = moire_score > 60.0

    return round(moire_score, 1), is_recaptured

def analyze_document_forensics(image_np: np.ndarray) -> Dict[str, Any]:
    """
    Executes full forensic pipeline:
    - Error Level Analysis (ELA)
    - 2D FFT Moiré / Screen Recapture check
    """
    if image_np is None or image_np.size == 0:
        return {
            "ela_score": 0.0,
            "moire_score": 0.0,
            "is_tampered": False,
            "is_screen_recapture": False,
            "tamper_flags": ["Invalid image data"],
            "heatmap_base64": ""
        }

    # 1. Run ELA
    diff_gray, overlay_heatmap, ela_score = compute_ela(image_np)

    # 2. Run Moiré screen recapture detector
    moire_score, is_recaptured = detect_moire_recapture(image_np)

    tamper_flags: List[str] = []
    is_tampered = False

    if ela_score > 60.0:
        is_tampered = True
        tamper_flags.append(f"High compression variance detected (ELA Score: {ela_score:.1f}/100) - potential photo or text splicing")
    elif ela_score > 35.0:
        tamper_flags.append(f"Moderate compression variance (ELA Score: {ela_score:.1f}/100) - warrants review")

    if is_recaptured:
        is_tampered = True
        tamper_flags.append(f"Periodic Moiré frequency grid detected (Moiré Score: {moire_score:.1f}/100) - physical screen re-capture")

    # Encode overlay heatmap to base64 for frontend display
    _, buffer = cv2.imencode(".jpg", overlay_heatmap, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
    heatmap_b64 = f"data:image/jpeg;base64,{base64.b64encode(buffer).decode('utf-8')}"

    return {
        "ela_score": ela_score,
        "moire_score": moire_score,
        "is_tampered": is_tampered,
        "is_screen_recapture": is_recaptured,
        "tamper_flags": tamper_flags,
        "heatmap_base64": heatmap_b64
    }
