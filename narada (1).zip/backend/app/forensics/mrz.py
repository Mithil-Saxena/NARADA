"""
NARADA Forensics - MRZ Processing & ICAO 9303 Deterministic Validation
Implements Section II.6: Deterministic standards-based checks for passports
and machine-readable travel documents (MRTD).
"""

import re
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

WEIGHTS = [7, 3, 1]

def char_to_value(char: str) -> int:
    """ICAO 9303 character valuation: 0-9 -> 0-9, A-Z -> 10-35, '<' -> 0."""
    char = char.upper()
    if char.isdigit():
        return int(char)
    elif 'A' <= char <= 'Z':
        return ord(char) - ord('A') + 10
    elif char == '<':
        return 0
    return 0

def calculate_check_digit(data_str: str) -> int:
    """Calculates ICAO 7-3-1 modulus 10 check digit for given field."""
    total = 0
    for idx, char in enumerate(data_str):
        weight = WEIGHTS[idx % 3]
        total += char_to_value(char) * weight
    return total % 10

def verify_check_digit(field_data: str, expected_digit_char: str) -> Tuple[bool, int, str]:
    """
    Verifies check digit against expected character.
    Returns (is_valid, calculated_digit, expected_char)
    """
    if not expected_digit_char.isdigit() and expected_digit_char != '<':
        return False, -1, expected_digit_char

    calc = calculate_check_digit(field_data)
    expected = 0 if expected_digit_char == '<' else int(expected_digit_char)
    return (calc == expected), calc, expected_digit_char

def parse_yymmdd(yymmdd_str: str, is_expiry: bool = False) -> Optional[str]:
    """Converts YYMMDD into YYYY-MM-DD format."""
    if len(yymmdd_str) != 6 or not yymmdd_str.isdigit():
        return None
    yy = int(yymmdd_str[0:2])
    mm = yymmdd_str[2:4]
    dd = yymmdd_str[4:6]

    current_year = datetime.now().year % 100
    if is_expiry:
        # Expiry is usually current century or near future
        full_year = 2000 + yy if yy <= current_year + 30 else 1900 + yy
    else:
        # DOB is usually past century or current
        full_year = 2000 + yy if yy <= current_year else 1900 + yy

    return f"{full_year}-{mm}-{dd}"

def parse_td3_mrz(lines: List[str]) -> Dict[str, Any]:
    """
    Parses standard 2-line x 44-character passport MRZ (ICAO Doc 9303 Part 4).
    """
    line1 = lines[0].strip().replace(" ", "").upper()
    line2 = lines[1].strip().replace(" ", "").upper()

    # Normalize length with '<' if slightly truncated
    line1 = (line1 + "<" * 44)[:44]
    line2 = (line2 + "<" * 44)[:44]

    # Line 1: Document Type (2), Issuing State (3), Names (39)
    doc_type = line1[0:2].replace("<", "")
    issuing_country = line1[2:5].replace("<", "")
    name_field = line1[5:44]

    names_split = name_field.split("<<", 1)
    surname = names_split[0].replace("<", " ").strip()
    given_names = names_split[1].replace("<", " ").strip() if len(names_split) > 1 else ""

    # Line 2:
    # 0-8: Document Number (9 chars)
    # 9: Check digit for Doc Number
    # 10-12: Nationality (3 chars)
    # 13-18: Date of Birth (YYMMDD)
    # 19: Check digit for DOB
    # 20: Sex (M/F/<)
    # 21-26: Expiry Date (YYMMDD)
    # 27: Check digit for Expiry
    # 28-41: Optional data / Personal Number (14 chars)
    # 42: Check digit for Optional data
    # 43: Composite check digit

    doc_num_raw = line2[0:9]
    doc_num_check = line2[9]
    nationality = line2[10:13].replace("<", "")
    dob_raw = line2[13:19]
    dob_check = line2[19]
    sex = line2[20].replace("<", "U")
    expiry_raw = line2[21:27]
    expiry_check = line2[27]
    opt_raw = line2[28:42]
    opt_check = line2[42]
    composite_check = line2[43]

    # Check digit validations
    doc_num_valid, calc_doc_chk, _ = verify_check_digit(doc_num_raw, doc_num_check)
    dob_valid, calc_dob_chk, _ = verify_check_digit(dob_raw, dob_check)
    expiry_valid, calc_exp_chk, _ = verify_check_digit(expiry_raw, expiry_check)

    # Composite check covers: doc_num+chk + dob+chk + expiry+chk + opt+chk
    composite_data = line2[0:10] + line2[13:20] + line2[21:43]
    composite_valid, calc_comp_chk, _ = verify_check_digit(composite_data, composite_check)

    # Overall validity
    all_valid = doc_num_valid and dob_valid and expiry_valid and composite_valid

    formatted_dob = parse_yymmdd(dob_raw, is_expiry=False)
    formatted_expiry = parse_yymmdd(expiry_raw, is_expiry=True)

    check_breakdown = [
        {"field": "Document Number Check Digit", "data": doc_num_raw, "expected": doc_num_check, "calculated": calc_doc_chk, "valid": doc_num_valid},
        {"field": "Date of Birth Check Digit", "data": dob_raw, "expected": dob_check, "calculated": calc_dob_chk, "valid": dob_valid},
        {"field": "Expiry Date Check Digit", "data": expiry_raw, "expected": expiry_check, "calculated": calc_exp_chk, "valid": expiry_valid},
        {"field": "Composite Overall Check Digit", "data": "Composite[0-42]", "expected": composite_check, "calculated": calc_comp_chk, "valid": composite_valid}
    ]

    return {
        "format": "TD3 (Passport)",
        "is_valid": all_valid,
        "doc_type": doc_type or "P",
        "issuing_country": issuing_country,
        "document_number": doc_num_raw.replace("<", ""),
        "surname": surname,
        "given_names": given_names,
        "full_name": f"{given_names} {surname}".strip(),
        "nationality": nationality,
        "dob": formatted_dob or dob_raw,
        "sex": sex,
        "expiry_date": formatted_expiry or expiry_raw,
        "optional_data": opt_raw.replace("<", ""),
        "checks": check_breakdown,
        "raw_lines": [line1, line2]
    }

def extract_and_parse_mrz(text_or_lines: Any) -> Optional[Dict[str, Any]]:
    """
    Searches for MRZ patterns in text or list of strings and parses.
    """
    if isinstance(text_or_lines, str):
        lines = [line.strip() for line in text_or_lines.splitlines() if line.strip()]
    elif isinstance(text_or_lines, list):
        lines = [str(l).strip() for l in text_or_lines if str(l).strip()]
    else:
        return None

    # Search for TD3 passport lines (2 lines with '<' characters, ~44 length)
    mrz_candidates = []
    for l in lines:
        cleaned = re.sub(r'[^A-Z0-9<]', '', l.upper())
        if len(cleaned) >= 38 and "<" in cleaned:
            mrz_candidates.append(cleaned[:44])

    if len(mrz_candidates) >= 2:
        # Take the last 2 candidates (MRZ is at the bottom of the page)
        return parse_td3_mrz(mrz_candidates[-2:])

    return None
