"""
Integration Test for NARADA FastAPI Server & Pipeline Endpoint
"""

import sys
import os
import unittest

# Add backend directory to sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.join(current_dir, "..", "backend")
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from fastapi.testclient import TestClient
from app.main import app
from app.scenarios import get_preloaded_scenarios

class TestNaradaAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)
        cls.scenarios = get_preloaded_scenarios()

    def test_health_endpoint(self):
        """Verify API health check."""
        res = self.client.get("/api/health")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["status"], "ONLINE")
        self.assertEqual(data["sih_id"], "SIH26188")

    def test_scenarios_endpoint(self):
        """Verify 5 demonstration scenarios endpoint."""
        res = self.client.get("/api/scenarios")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(len(data), 5)

    def test_pipeline_scenario_1_genuine(self):
        """Test Scenario 1 (Genuine Passport) -> Expect CONSISTENT (Green)."""
        sc = self.scenarios[0]
        payload = {
            "doc_image_b64": sc["doc_image_b64"],
            "live_selfie_b64": sc["live_selfie_b64"],
            "screening_mode": "DEEP",
            "edge_mode": "OFFLINE"
        }
        res = self.client.post("/api/screen/pipeline", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["status"], "SUCCESS")
        self.assertEqual(data["adversarial_report"]["assurance_state"], "CONSISTENT")
        self.assertEqual(data["adversarial_report"]["state_color"], "GREEN")
        self.assertTrue(data["quality_gate"]["passed"])

    def test_pipeline_scenario_2_impostor(self):
        """Test Scenario 2 (Impostor Person) -> Expect HIGH_CONFIDENCE_FRAUD (Red)."""
        sc = self.scenarios[1]
        payload = {
            "doc_image_b64": sc["doc_image_b64"],
            "live_selfie_b64": sc["live_selfie_b64"],
            "screening_mode": "DEEP",
            "edge_mode": "OFFLINE"
        }
        res = self.client.post("/api/screen/pipeline", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["adversarial_report"]["assurance_state"], "HIGH_CONFIDENCE_FRAUD")
        self.assertEqual(data["adversarial_report"]["state_color"], "RED")

    def test_pipeline_scenario_4_cross_document(self):
        """Test Scenario 4 (Cross-Doc Conflict) -> Expect INCONSISTENT (Orange)."""
        sc = self.scenarios[3]
        payload = {
            "doc_image_b64": sc["doc_image_b64"],
            "live_selfie_b64": sc["live_selfie_b64"],
            "secondary_doc_b64": sc["secondary_doc_b64"],
            "screening_mode": "DEEP",
            "edge_mode": "OFFLINE"
        }
        res = self.client.post("/api/screen/pipeline", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["adversarial_report"]["assurance_state"], "INCONSISTENT")
        self.assertEqual(data["adversarial_report"]["state_color"], "ORANGE")
        self.assertTrue(data["cross_check"]["active"])
        self.assertGreater(len(data["cross_check"]["contradictions"]), 0)

if __name__ == "__main__":
    unittest.main()
